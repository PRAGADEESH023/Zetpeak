  import 'package:flutter/services.dart';
  import 'package:flutter/material.dart';
  import 'package:splash_screen_view/SplashScreenView.dart';
  import 'package:sizer/sizer.dart';
  
  
  
  
  import 'package:myapp/src/pages/entrypoint/page.dart';
  import 'package:teta_cms/teta_cms.dart';

  void main() async {
    WidgetsFlutterBinding.ensureInitialized();
    await SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
    ]);
    TetaCMS.initialize(
      token: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImhhY2tlcm1hc3MxMUBnbWFpbC5jb20iLCJlbWFpbF92ZXJpZmllZCI6dHJ1ZSwicHJvamVjdHMiOlsxNDgxNDYsMTQ4MTM4LDE0ODQ1MV0sImltYWdlIjoiaHR0cHM6Ly9saDMuZ29vZ2xldXNlcmNvbnRlbnQuY29tL2EtL0FGZFp1Y3E1VFJLTGtvWEpqOFo0Wm9ZMHIzVUVFeE9wajRvdGRjdk5XU0ltX0E9czk2LWMiLCJuYW1lIjoiTXIgTHVjaWZlciIsImVtaXR0ZXIiOiJUZXRhLUF1dGgiLCJpYXQiOjE2NTg3NTI1NjcsImV4cCI6NDgxNDUxMjU2N30.CJo4G1iUDxGbw20Gw2WgcrNPe-wgRwMDza1_NiDnoMU',
      prjId: 148146,
    );
    
    
    
    
    runApp(MyApp());
  }
  class MyApp extends StatelessWidget {
    @override
    Widget build(BuildContext context) {
      return Sizer(
        builder: (
          final context,
          final orientation,
          final deviceType,
        ) => MaterialApp(
          title: 'pragadeesh',
          home: SplashScreenView(
            navigateRoute: PageEntryPoint(),
            duration: 2200,
            imageSize: 80,
            imageSrc: 'assets/teta-app.png',
            text: '',
            textType: TextType.NormalText,
            textStyle: TextStyle(
              fontSize: 30.0,
            ),
            backgroundColor: Colors.black,
          ),
        ),
      );
    }
  }
  