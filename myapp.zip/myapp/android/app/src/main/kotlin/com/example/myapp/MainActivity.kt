package com.example.myapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
